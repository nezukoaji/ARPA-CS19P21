using UiPath.CodedWorkflows;
using System;

namespace ex7libraryfinesystem
{
    public class ConnectionsManager
    {
        public ConnectionsManager(ICodedWorkflowsServiceContainer resolver)
        {
        }
    }
}